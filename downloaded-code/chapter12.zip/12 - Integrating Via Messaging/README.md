PPPDDD
======

See chapter 12 in the book for guidance on setting up and running this project, 
including NServiceBus and MSMQ installation instructions.
