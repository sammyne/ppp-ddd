﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPPDDDChap19.eBidder.Listings.Application.Watching.BusinessUseCases
{
    public class WatchItem
    {
        public Guid MemberId { get; set; }
        public Guid AuctionId { get; set; }
    }
}
