﻿using System;

namespace DDDPPP.Chap21.MicroORM.Application.Infrastructure
{
    public interface IAggregateDataModel
    {
    }
}
