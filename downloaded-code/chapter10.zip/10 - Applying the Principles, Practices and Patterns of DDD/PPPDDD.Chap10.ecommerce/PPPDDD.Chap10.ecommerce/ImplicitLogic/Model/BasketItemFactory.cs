﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPPDDD.Chap10.ecommerce.ImplicitLogic.Model
{
    public class BasketItemFactory
    {
        internal static BasketItem create_item_for(Product product, basket basket)
        {
            throw new NotImplementedException();
        }
    }
}
