﻿namespace Agathas.Storefront.Shopping.Model.Promotions
{
    public class Coupon
    {
        public string code { get; set; }
    }
}