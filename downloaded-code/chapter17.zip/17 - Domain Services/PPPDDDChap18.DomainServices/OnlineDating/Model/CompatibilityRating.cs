﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPPDDDChap18.DomainServices.OnlineDating.Model
{
    public class CompatibilityRating
    {
        public CompatibilityRating Boost(CompatibilityRating rating)
        {
            // ..
            return null;
        }

        // ..
    }
}
