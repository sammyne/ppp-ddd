﻿using System;

namespace DDDPPP.Chap21.EFExample.Application.Model.Auction
{
    public class MoneyCannotBeANegativeValueException : Exception
    {
    }
}
