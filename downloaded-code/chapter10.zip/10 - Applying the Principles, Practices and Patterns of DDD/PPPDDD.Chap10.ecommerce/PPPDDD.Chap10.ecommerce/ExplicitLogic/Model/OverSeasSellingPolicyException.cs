﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PPPDDD.Chap10.ecommerce.ExplicitLogic.Model
{
    class OverSeasSellingPolicyException : Exception
    {
        public OverSeasSellingPolicyException(string message)
        {
        }
    }
}
