﻿CREATE TABLE [dbo].[LoyaltySettings]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[Month] DATE NOT NULL,
	[PointsPerDollar] INT NOT NULL
)
