﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PPPDDD.Chap10.ecommerce.ExplicitLogic.Model
{
    public class Country
    {
    }
}
