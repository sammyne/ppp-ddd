﻿using System;

namespace DDDPPP.Chap21.NHibernateExample.Application.Model.Auction
{
    public class MoneyCannotBeANegativeValueException : Exception
    {
    }
}
