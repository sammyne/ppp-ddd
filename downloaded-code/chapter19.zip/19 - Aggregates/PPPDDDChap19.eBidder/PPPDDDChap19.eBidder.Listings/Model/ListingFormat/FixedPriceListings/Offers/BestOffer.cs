﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPPDDDChap19.eBidder.Listings.Model.Auctions.Offers
{
    public class BestOffer
    {
        public void CounterOffer()
        {
            //price and terms, and click 'Send'.
        }
    }
}
