﻿using Agathas.Storefront.Infrastructure;

namespace Agathas.Storefront.Shopping.Commands
{
    public class UpdateBasketDeliveryCountry : IBusinessRequest
    {
        
    }
}