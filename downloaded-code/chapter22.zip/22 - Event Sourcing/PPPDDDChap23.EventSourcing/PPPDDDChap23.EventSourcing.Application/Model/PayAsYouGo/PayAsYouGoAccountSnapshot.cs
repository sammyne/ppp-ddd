﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPPDDDChap23.EventSourcing.Application.Model.PayAsYouGo
{
    public class PayAsYouGoAccountSnapshot
    {
        public int Version { get; set; }

        public decimal Credit { get; set; }
    }
}
