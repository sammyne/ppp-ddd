﻿using System;

namespace DDDPPP.Chap21.NHibernateExample.Application.Infrastructure
{
    public interface IClock
    {
        DateTime Time();
    }
}
