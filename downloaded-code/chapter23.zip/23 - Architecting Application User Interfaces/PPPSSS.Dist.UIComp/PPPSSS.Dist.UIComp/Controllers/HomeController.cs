﻿using System;
using System.Web;
using System.Web.Mvc;

namespace PPPSSS.Dist.UIComp.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }
    }
}