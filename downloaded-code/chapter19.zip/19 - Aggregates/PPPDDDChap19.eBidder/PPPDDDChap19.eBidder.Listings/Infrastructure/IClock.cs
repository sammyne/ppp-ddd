﻿using System;

namespace PPPDDDChap19.eBidder.Listings.Application.Infrastructure
{
    public interface IClock
    {
        DateTime Time();
    }
}
