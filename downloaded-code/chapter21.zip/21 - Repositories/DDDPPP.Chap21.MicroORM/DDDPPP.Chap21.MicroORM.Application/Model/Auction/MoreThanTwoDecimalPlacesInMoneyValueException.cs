﻿using System;

namespace DDDPPP.Chap21.MicroORM.Application.Model.Auction
{
    public class MoreThanTwoDecimalPlacesInMoneyValueException : Exception
    {
    }
}
