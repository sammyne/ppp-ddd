﻿using System;
using Agathas.Storefront.Common;
using Agathas.Storefront.Shopping.Model.Promotions;

namespace Agathas.Storefront.Shopping.Model.Baskets
{
    public class BasketPricingBreakdown
    {
        public Money basket_total
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        public Money discount
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        public CouponIssues coupon_message
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }
    }
}