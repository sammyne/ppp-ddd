﻿namespace Agathas.Storefront.Shopping.Model.Promotions
{
    public interface ICouponPolicy
    {
    }
}
