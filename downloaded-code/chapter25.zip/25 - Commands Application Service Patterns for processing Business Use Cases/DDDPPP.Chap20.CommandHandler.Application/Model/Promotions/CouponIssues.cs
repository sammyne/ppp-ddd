﻿namespace Agathas.Storefront.Shopping.Model.Promotions
{
    public enum CouponIssues
    {
        NotApplied = 0,
        NoIssue = 1

    }
}
