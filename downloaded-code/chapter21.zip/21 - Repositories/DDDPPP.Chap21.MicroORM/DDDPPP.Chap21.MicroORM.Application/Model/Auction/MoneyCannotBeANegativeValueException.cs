﻿using System;

namespace DDDPPP.Chap21.MicroORM.Application.Model.Auction
{
    public class MoneyCannotBeANegativeValueException : Exception
    {
    }
}
