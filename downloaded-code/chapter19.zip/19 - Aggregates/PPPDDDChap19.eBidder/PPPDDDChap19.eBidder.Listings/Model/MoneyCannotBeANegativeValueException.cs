﻿using System;

namespace PPPDDDChap19.eBidder.Listings.Model
{
    public class MoneyCannotBeANegativeValueException : Exception
    {
    }
}
