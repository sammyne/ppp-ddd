﻿using System;

namespace DDDPPP.Chap21.RavenDBExample.Application.Model.Auction
{
    public class MoreThanTwoDecimalPlacesInMoneyValueException : Exception
    {
    }
}
