﻿using Agathas.Storefront.Infrastructure;

namespace Agathas.Storefront.Shopping.Model.Baskets.Events
{
    public class CouponNotApplicableForBasketItems : IDomainEvent
    {
    }
}